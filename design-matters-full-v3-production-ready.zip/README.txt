Design Matters — full ZIP v3 front-end + Supabase integration

Source: design-matters-subscribe-profile-v3.zip
Deploy these two files into the root of crw0712-hub/design-matters, replacing existing index.html and profile-live.html.
Existing dm-member-nav.js and dm-member-client.js are required and already in the repository.

After upload, GitHub Pages runs automatically.
Register: homepage topic cards -> benefits -> email -> server account creation -> Profile.
Sign in again: top-right Profile -> email magic link (configured SMTP required for public email delivery).
